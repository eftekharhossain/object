interface Image {
    void run();
    void image();
}
