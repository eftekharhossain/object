public class MultipleInheritanceExample {
    public static void main(String[] args) {
       
        Laptop obj = new Laptop();
        obj.powerOn();
        obj.run();
        obj.music();
        obj.image();
        obj.powerOff();
    }
}
