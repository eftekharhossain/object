interface Music{
    void run();
    void music();
}
