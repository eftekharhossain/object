public interface IOrder {
    public void fulfillOrder(Order order);
}