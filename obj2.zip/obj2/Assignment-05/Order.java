import java.util.List;

public class Order {
    List<Item> itemList;

    public Order(List<Item> itemList) {
        this.itemList = itemList;
    }
}
