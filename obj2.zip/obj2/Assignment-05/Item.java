public class Item {
    String sku;

    public Item(String sku) {
        this.sku = sku;
    }
}
