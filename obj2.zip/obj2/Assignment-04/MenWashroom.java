public class MenWashroom extends Room {
    public MenWashroom(){
        super("1F Men's Washroom");
    }
}
