public class WomenWashroom extends Room {
    public WomenWashroom() {
        super("1F Women's Washroom");
    }
}
