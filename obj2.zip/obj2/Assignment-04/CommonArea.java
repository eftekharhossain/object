public class CommonArea extends Room {
    public CommonArea(){
        super("1F Common Area");
    }
}
