public interface WebPage {
    public void display();
}